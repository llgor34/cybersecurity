===========[Dziękujemy-za-pobranie]===========

Dziękujemy za pobranie naszego plakatu, razem
z plakatem znajduje się plik tekstowy z całą
zawartością naszej strony.

=================[Wymagania]==================

Plakat oraz treść plików tekstowych w tej
paczce jest własnością zespołu Pixel-Cop™
i zastrzegamy sobie praw do tych treści.

W przypadku użycia naszych treści zostaw 
wiadomość czytelnikowi iż jest to własność
Pixel-Cop™.

===================[Cele]=====================

Celem naszej prezentacji jest ukazanie 
niebezpieczeństw czychających na 
internautów w sieci.

==============================================
